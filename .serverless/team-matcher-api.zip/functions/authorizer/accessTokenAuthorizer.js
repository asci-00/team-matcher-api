const jsonwebtoken = require('jsonwebtoken');
const jwkToPem = require('jwk-to-pem');
const axios = require('axios');
const AWS = require('aws-sdk');

console.log('Loading function');

const { REGION, USER_POOL_ID } = process.env;

const validateToken = async (event, context) => {
  const iss = `https://cognito-idp.${REGION}.amazonaws.com/${USER_POOL_ID}/.well-known/jwks.json`;
  const { authorizationToken: token } = event;

  const { kid } = decodeTokenHeader(token);

  const { data } = await axios.get(iss);
  const { keys: jsonWebKeys } = data;

  const jsonWebKey = getJsonWebKeyWithKID(kid, jsonWebKeys);
  verifyJsonWebTokenSignature(token, jsonWebKey, iss, (err) => {
    if (err) {
      context.fail('Unauthorized');
      console.log(err);
    } else {
      const cognitoIdentityServiceProvider =
        new AWS.CognitoIdentityServiceProvider({ region: REGION });
      cognitoIdentityServiceProvider.getUser(
        { AccessToken: token },
        (err, data) => {
          if (err) {
            context.fail('Unauthorized');
            console.log(err);
          } else {
            console.log('Session not revoked');
            const { Value: sub } = data.UserAttributes[0];

            context.succeed(generatePolicy(sub, 'Allow', event.methodArn));
            // context.succeed({
            //   principalId: sub,
            //   policyDocument: {
            //     Version: '2012-10-17',
            //     Statement: [
            //       {
            //         Action: 'execute-api:Invoke',
            //         Effect: 'Allow',
            //         Resource: event.methodArn,
            //       },
            //     ],
            //   },
            // });
          }
        }
      );
    }
  });
};

function generatePolicy(principalId, effect, resource) {
  // Required output:
  const authResponse = {};
  authResponse.principalId = principalId;
  if (effect && resource) {
    const policyDocument = {};
    policyDocument.Version = '2012-10-17'; // default version
    policyDocument.Statement = [];
    const statementOne = {};
    statementOne.Action = 'execute-api:Invoke'; // default action
    statementOne.Effect = effect;
    statementOne.Resource = resource;
    policyDocument.Statement[0] = statementOne;
    authResponse.policyDocument = policyDocument;
  }
  // Optional output with custom properties of the String, Number or Boolean type.
  authResponse.context = {
    stringKey: 'stringval',
    numberKey: 123,
    booleanKey: true,
  };
  return authResponse;
}

function decodeTokenHeader(token) {
  const [headerEncoded] = token.split('.');
  const buff = Buffer.from(headerEncoded, 'base64');
  const text = buff.toString('ascii');
  return JSON.parse(text);
}

function getJsonWebKeyWithKID(kid, jsonWebKeys) {
  for (let jwk of jsonWebKeys) {
    if (jwk.kid === kid) {
      return jwk;
    }
  }
  return null;
}

function verifyJsonWebTokenSignature(token, jsonWebKey, iss, clbk) {
  const pem = jwkToPem(jsonWebKey);
  jsonwebtoken.verify(token, pem, { algorithms: ['RS256'] }, clbk);
}

module.exports.handler = validateToken;
